
class Module1:
    def reply():
        return 'Module 1 Hello World'