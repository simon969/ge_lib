class genericobject:
    pass