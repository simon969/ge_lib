class genericobject:
    pass