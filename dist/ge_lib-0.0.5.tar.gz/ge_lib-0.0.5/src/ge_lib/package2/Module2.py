

class Module2:
    def reply():
        return 'Module 2 Hello World'